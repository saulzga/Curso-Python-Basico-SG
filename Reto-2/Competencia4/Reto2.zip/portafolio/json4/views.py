from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from django.template.loader import render_to_string
import json

def post(request):
    datos = {"Nombre": "Saul", 
                "Primer Apellido":"Gomez",
                "Segundo Apellido":"Garcia",
                "Fecha de nacimiento":1993,
                "Celular": 3311223344,
                "Correo": "saul@python.mx",
                "Domicilio":"Avenida Primera #4",
                "Genero":"Hombre",
                "Objetivo": "Finalizar curso de Python Basico",
                "Salario Esperado": 100000
                }
    return JsonResponse(datos)

def post2(request):

    skills = ["Python Basico", "Formato en CSS", "Ambiente Django"]
 
    return JsonResponse(skills, safe=False)

def post3(request):


    trabajos = {"Trabajo mas reciente":{"lugar_trabajo": "HPE", "año_inicio":2021,"año_fin": "Trabajo actual","Puesto":"SIO"},
                "Trabajo Anterior":{"lugar_trabajo": "Black Box", "año_inicio":2020,"año_fin": 2021,"Puesto":"SIO"}}
 
    return JsonResponse(trabajos)
