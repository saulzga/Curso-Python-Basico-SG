from django.http import HttpResponse
from django.views import View
from django.shortcuts import render, redirect

# Create your views here.

class DatosPersonales(View):
    def post(self, request):
        return render(request)

    
    def get(self,request):
        datos = {"Nombre": "Saúl", 
                 "Primer Apellido":"Gómez",
                 "Segundo Apellido":"García",
                 "Fecha de nacimiento":1993,
                 "Celular": 3311223344,
                 "Correo": "saul@python.mx",
                 "Domicilio":"Avenida Primera #4",
                 "Género":"Hombre",
                 "Objetivo": "Finalizar curso de Python Básico",
                 "Salario Esperado": 100000
                 }
        skills = ["Python Básico", "Formato en CSS", "Ambiente Django"]
        LtoD= dict.fromkeys(skills, "placeholder")
        trabajos = {"Trabajo más reciente":{"lugar_trabajo": "HPE", "año_inicio":2021,"año_fin": "Trabajo actual","Puesto":"SIO"},
                    "Trabajo Anterior":{"lugar_trabajo": "Black Box", "año_inicio":2020,"año_fin": 2021,"Puesto":"SIO"}}
        context = {'datos':datos, 'LtoD':LtoD, 'trabajos':trabajos}
        return render(request,"CV.html",context)




