from django.http import HttpResponse
from django.views import View
from django.shortcuts import render, redirect

# Create your views here.

class Inicio(View):
    template_name= "Inicio.html"

    def post (self, request):
        return render (request)
    
    def get(self, request):
    
        return render(request,self.template_name)
        